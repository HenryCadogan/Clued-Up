----------------
--- Clued Up ---
----------------

A brief overview of the file structure for our game:

Every resource we use is in \Assets

\Assets contains the scenes - the .unity files.
\Assets\Editor contains the .cs files used in our testing. The tests can be run within the Unity Edity through Window-> Editor Test Runner and running the tests as needed.
\Assets\Resources contains most of the text files referenced in the game.
\Assets\Scripts contains all of the .cs files that we've made for the game.
\Assets\Fonts contains the fonts used in the UI

----------------